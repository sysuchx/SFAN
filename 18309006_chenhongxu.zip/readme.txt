环境配置：pip install -r requirements.txt
数据集下载： CUHK-SYSU和PRW数据集，放置格式：
$ROOT/data
├── CUHK-SYSU
└── PRW

训练：
CUHK-SYSU数据集：python train.py --cfg configs/cuhk_sysu.yaml
PRW数据集：python train.py --cfg configs/prw.yaml

batch_size默认为5，学习率默认为0.003。如果GPU显存不足，则可以调整batch_size的大小：
python train.py --cfg configs/cuhk_sysu.yaml INPUT.BATCH_SIZE_TRAIN 2 SOLVER.BASE_LR 0.0012
注意batch_size和学习率需要按比例变化。

测试：
注意：epoch_X.pth需要训练并放到指定文件夹下
1.普通测试方法：
CUHK-SYSU数据集：
python train.py --cfg $ROOT/exp_cuhk/config.yaml --eval --ckpt 
$ROOT/exp_cuhk/epoch_X.pth 

PRW数据集：
python train.py --cfg $ROOT/exp_prw/config.yaml --eval --ckpt 
$ROOT/exp_prw/epoch_X.pth 

2.使用CBGM方法测试：
CUHK-SYSU数据集：
python train.py --cfg $ROOT/exp_cuhk/config.yaml --eval --ckpt $ROOT/exp_cuhk/epoch_X.pth EVAL_USE_CBGM True

PRW数据集：
python train.py --cfg $ROOT/exp_prw/config.yaml --eval --ckpt 
$ROOT/exp_prw/epoch_X.pth EVAL_USE_CBGM True

3.使用行人重识别方法测试：
CUHK-SYSU数据集：
python train.py --cfg $ROOT/exp_cuhk/config.yaml --eval --ckpt $ROOT/exp_cuhk/epoch_X.pth EVAL_USE_GT True

PRW数据集：
python train.py --cfg $ROOT/exp_prw/config.yaml --eval --ckpt $ROOT/exp_prw/epoch_X.pth EVAL_USE_GT True
