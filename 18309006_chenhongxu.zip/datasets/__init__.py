from .build import build_test_loader, build_train_loader
