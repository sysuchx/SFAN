from collections import OrderedDict

import torch.nn.functional as F
import torchvision
import torch
from torch import nn
# from lib.non_local_gaussian import NONLocalBlock2D
# from non_local_concatenation import NONLocalBlock2D
# from non_local_dot_product import NONLocalBlock2D
from non_local_embedded_gaussian import NONLocalBlock2D
# -----------------------------------------------------------3.14
import scipy.io as io
import numpy as np
from PIL import Image
import pdb
# --------------------------------------------------------------

class Backbone(nn.Sequential):
    def __init__(self, resnet):
        # print('resnet',resnet)
        super(Backbone, self).__init__(
            OrderedDict(
                [
                    ["conv1", resnet.conv1],
                    ["bn1", resnet.bn1],
                    ["relu", resnet.relu],
                    ["maxpool", resnet.maxpool],
                    ["layer1", resnet.layer1],  # res2
                    ["layer2", resnet.layer2],  # res3
                    ["layer3", resnet.layer3],  # res4
                ]
            )
        )
        self.selfNONLocalBlock2D = NONLocalBlock2D(1024, sub_sample=False, bn_layer=True).cuda()

        self.out_channels = 1024

    def forward(self, x):
        # using the forward method from nn.Sequential
        # print(x.shape,'xshape([1, 3, 864, 1504]')
        # img = x.mul(255).byte()
        # # img = img.cpu().numpy().squeeze(0).transpose((1, 2, 0))
        # img = img.cpu().numpy().squeeze(0).transpose((1, 2, 0))
        # # print(img.shape,'img')
        # img = Image.fromarray(img, 'RGB')
        # # print(img.size, 'img222')
        # img.save('zhangquan2.jpg')



        # y=x.squeeze(axis=0)

        # print(y.shape,'result1')
        # y=y.cpu()
        # print(y.shape,'result2')
        # image = unloader(y)
        # print(image.shape, 'resul3')
        #
        # img = Image.fromarray(y, 'RGB')
        # print(img.size)
        # img.save('zhangquan2.jpg')
        # result1=np.concatenate((result1, result1, result1), axis=-1)
        # img = Image.fromarray(result1, 'RGB')
        # print(img.size,'img')


        feat = super(Backbone, self).forward(x)

        # ----------------------------------------------------------------------
        # print('1111111111111111111111111111111111111111111111111111111111111111111111111111')
        #
        #
        #
        # # result=torch.sum(feat, dim=1).squeeze(0)
        # result=feat.squeeze(0)
        # result=result[0]
        #
        #
        #
        #
        #
        # # print(feat.shape([5, 1024, 58, 94]  54)
        # result1 = np.array(result.cpu())
        # result1=np.concatenate((result1, result1, result1), axis=-1)
        # img = Image.fromarray(result1, 'RGB')
        # print(img.size,'img')

# ----------------------------------------------------------归一化
#         ymax = 255
#         ymin = 0
#         xmax = max(map(max, result1))
#         xmin = min(map(min, result1))
#
#         for i in range(54):
#             for j in range(94):
#                 # result1[i][j] = 255
#                 result1[i][j] = round(((ymax - ymin) * (result1[i][j] - xmin) / (xmax - xmin)) + ymin)
#                 # result1[i][j]=255-result1[i][j]
#                 if (result1[i][j] < 50):
#                     result1[i][j] = 0
#                 # if (result1[i][j] > 230):
#                 #     result1[i][j] = 255
#         img = Image.fromarray(result1)
#
#         img = img.convert('L')  # 这样才能转为灰度图，如果是彩色图则改L为‘RGB’
#         img.save('zhangquan114.jpg')
#
#         # img3 = Image.fromarray(result1)
#         # print(img3.size, 'img3')
#
#
#
#         src_new = np.zeros((54,94,3)).astype("uint8")
#         src_new[:, :, 0] = result1
#         # src_new[:, :, 1] = result1
#         # src_new[:, :, 2] = result1
#
#
#         # src_new=Image.fromarray(src_new)
#         img3=Image.fromarray(src_new, 'RGB')
#         io.savemat('src_new.mat', {'src_new': src_new})
#         # img3 = src_new.convert('RGB')  # 这样才能转为灰度图，如果是彩色图则改L为‘RGB’
#         img3.save('zhangquanpre.jpg')
#

# ----------------------------------------------------------归一化


        # np.savetxt('npresult1.txt', result1)
        # io.savemat('save.mat', {'result1': result1})

        # print(feat.shape, 'featshape')
        # print(feat,'feat0')
        # print(feat.shape([5, 1024, 58, 94])

        # print(feat[0].shape)
        feat = self.selfNONLocalBlock2D(feat)
        # print('222222222222222222222222222222222222222222222222222222222222222222222222222222222')
        #
        # result4 = torch.sum(feat, dim=1).squeeze(0)
        # # print(feat.shape([5, 1024, 58, 94]  54)
        # result5 = np.array(result4.cpu())
        # # result1=np.concatenate((result1, result1, result1), axis=-1)
        # # img = Image.fromarray(result1, 'RGB')
        # # print(img.size,'img')
        #
        #
        # # ----------------------------------------------------------归一化
        # ymax = 255
        # ymin = 0
        # xmax = max(map(max, result5))
        # xmin = min(map(min, result5))
        #
        # for i in range(54):
        #     for j in range(94):
        #         result5[i][j] = round(((ymax - ymin) * (result5[i][j] - xmin) / (xmax - xmin)) + ymin)
        #         if(result5[i][j]<70):
        #             result5[i][j]=0
        #         #
        #         # if (result5[i][j] > 230):
        #         #     result5[i][j] = 255
        #         # result1[i][j]=255-result1[i][j]
        #
        # img = Image.fromarray(result5)
        # img = img.convert('L')  # 这样才能转为灰度图，如果是彩色图则改L为‘RGB’
        # img.save('zhangquan114514.jpg')
        #
        #
        # src_new1 = np.zeros((54, 94, 3)).astype("uint8")
        # src_new1[:, :, 0] = result5
        # # src_new[:, :, 1] = result1
        # # src_new[:, :, 2] = result1
        #
        # # src_new=Image.fromarray(src_new)
        # img4 = Image.fromarray(src_new1, 'RGB')
        # io.savemat('src_new1.mat', {'src_new1': src_new1})
        # # img3 = src_new.convert('RGB')  # 这样才能转为灰度图，如果是彩色图则改L为‘RGB’
        # img4.save('zhangquanafter.jpg')
        #
        # src_new2 = np.zeros((54, 94)).astype("uint8")
        # for i in range(54):
        #     for j in range(94):
        #         # result1[i][j] = 255
        #         if result1[i][j] > result5[i][j]:
        #             src_new2[i][j]=255
        #         else:
        #             src_new2[i][j]=0
        #
        # img = Image.fromarray(src_new2)
        # img = img.convert('L')  # 这样才能转为灰度图，如果是彩色图则改L为‘RGB’
        # img.save('zhangquanfinal.jpg')
        #
        # # img4 = Image.fromarray(result1)
        # # print(img4.size, 'img4')
        # #
        # # img4 = img4.convert('RGB')  # 这样才能转为灰度图，如果是彩色图则改L为‘RGB’
        # # img4.save('zhangquanafter.jpg')
        #
        # # ----------------------------------------------------------归一化
        #
        #
        # pdb.set_trace()
        #
        # np.savetxt('npresult2.txt', result5)
        # io.savemat('save2.mat', {'result5': result5})
        #
        # # print(feat)
        # print(feat, 'feat1')
        return OrderedDict([["feat_res4", feat]])




class Res5Head(nn.Sequential):
    def __init__(self, resnet):
        super(Res5Head, self).__init__(OrderedDict([["layer4", resnet.layer4]]))  # res5
        self.out_channels = [1024, 2048]

    def forward(self, x):
        feat = super(Res5Head, self).forward(x)
        x = F.adaptive_max_pool2d(x, 1)
        feat = F.adaptive_max_pool2d(feat, 1)
        return OrderedDict([["feat_res4", x], ["feat_res5", feat]])


def build_resnet(name="resnet50", pretrained=True):
    resnet = torchvision.models.resnet.__dict__[name](pretrained=pretrained)

    # freeze layers
    resnet.conv1.weight.requires_grad_(False)
    resnet.bn1.weight.requires_grad_(False)
    resnet.bn1.bias.requires_grad_(False)

    return Backbone(resnet), Res5Head(resnet)



# --------------------------------------------------------------------------------
# CUDA_VISIBLE_DEVICES='1' python train.py --cfg exp_cuhknon1212/config.yaml --eval --ckpt exp_cuhknon1212/epoch_16.pth EVAL_USE_CBGM True
# 这个是CUHK-SYSU的代码，训练16次，仅在resnet里加一层nonlocl，cbgm测试达到96.61 89.69 96.1 96.7 上采样=True

# CUDA_VISIBLE_DEVICES='1' python train.py --cfg exp_cuhknon1212/config.yaml --eval --ckpt exp_cuhknon1212/epoch_17.pth EVAL_USE_GT True
# 96.4 97.0上采样=True


# -------------------------------------------------------------------------------------------------------
# CUDA_VISIBLE_DEVICES='3' python train.py --cfg prw12_19/config.yaml --eval --ckpt prw12_19/epoch_14.pth EVAL_USE_CBGM True
# 此时 False 下采样
# 9726 9479 48.2 87.6